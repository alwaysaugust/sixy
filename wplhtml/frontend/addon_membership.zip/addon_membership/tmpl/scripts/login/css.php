<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
    html.wpl-interim-login #wpl_login_form{margin:0;border:none;display:inline-block;max-width:none;width:100%}html.wpl-interim-login #wpl_login_form .wpl_membership_addon_label{border-bottom:1px solid #ddd;padding:8px;position:relative;padding-left:50px}html.wpl-interim-login #wpl_login_form .wpl_membership_addon_label::before{position:absolute;height:100%;top:0;padding:10px;left:0}html.wpl-interim-login #wpl_login_form .wpl-login-form-row{padding:5px 15px}html.wpl-interim-login #wpl_login_form label{width:100px;text-align:right}html.wpl-interim-login #wpl_login_form .wpl-login-form-btns-wp{text-align:right}html.wpl-interim-login #wpl_login_form .wpl-login-form-remember-wp{padding-left:120px}html.wpl-interim-login #wpl_login_form .wpl-login-form-remember-wp label{text-align:left;margin-left:5px}
</style>