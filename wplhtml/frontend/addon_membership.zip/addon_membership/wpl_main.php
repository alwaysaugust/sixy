<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');

_wpl_import('views.frontend.addon_membership.wpl_abstract');

class wpl_addon_membership_controller extends wpl_addon_membership_controller_abstract
{
    public $wplraw = 0;
}