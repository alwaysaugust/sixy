<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');

$this->_wpl_import($this->tpl_path.'.scripts.listing', true, ($this->wplraw ? false : true));
?>
<div class="wpl-save-search-addon wpl-addon-save-search-list-wp <?php echo wpl_request::getVar('wpl_dashboard', 0) ? '' : 'wpl_view_container'; ?>" id="wpl_addon_save_searches_container">

    <?php if($this->users->is_administrator() and $this->user_id != $this->users->get_cur_user_id()): ?>
        <div class="wpl-addon-save-search-username"><?php echo sprintf(__('Saved Searches of %s', 'real-estate-listing-realtyna-wpl'), '<span>'.$this->user_data->data->user_login.'</span>'); ?></div>
    <?php endif; ?>

    <?php if($this->users->is_administrator() and wpl_sef::is_permalink_default()): ?>
        <div class="wpl_message_container"><?php echo __("To use the alias feature of the Saved Searches Add-on, your WordPress Permalink structure should not be set to default", 'real-estate-listing-realtyna-wpl'); ?></div>
    <?php endif; ?>

    <div class="wpl-save-search-msg" id="wpl_save_searches_list_show_messages"></div>

    <table class="wpl-gen-grid-wp wpl-gen-grid-center wpl-addon-save-search-grid" id="wpl_addon_save_searches_list_container">
        <thead>
            <tr>
                <th><?php echo __('Search', 'real-estate-listing-realtyna-wpl'); ?></th>
                <th><?php echo __('Created', 'real-estate-listing-realtyna-wpl'); ?></th>
                <?php if($this->users->is_administrator() and !wpl_sef::is_permalink_default()): ?>
                <th><?php echo __('Alias', 'real-estate-listing-realtyna-wpl'); ?></th>
                <th><?php echo __('Link', 'real-estate-listing-realtyna-wpl'); ?></th>
                <?php endif; ?>
                <th><?php echo __('Notify mode', 'real-estate-listing-realtyna-wpl'); ?></th>
                <th><?php echo __('Criteria', 'real-estate-listing-realtyna-wpl'); ?></th>
                <th><span class="wpl-addon-save-search-remove-btn" id="wpl_addon_save_searches_delete_all" onclick="wpl_addon_save_searches_delete_all(<?php echo $this->user_id; ?>, 0);" title="<?php echo __('Delete All', 'real-estate-listing-realtyna-wpl'); ?>"></span></th>
            </tr>
        </thead>

        <tbody>

            <?php foreach($this->searches as $search): ?>
            <tr id="wpl_addon_save_search_item<?php echo $search['id']; ?>">

                <td><div id="wpl_save_search_name_content<?php echo $search['id']; ?>" class="wpl_save_search_name_content"><a target="_blank" id="wpl_save_search_name<?php echo $search['id']; ?>" href="<?php echo $search['url']; ?>"><?php echo $search['name']; ?></a>
		                <span id="wpl_save_search_edit_name<?php echo $search['id']; ?>" class="wpl-addon-save-search-edit-btn" onclick="wpl_addon_save_searches_edit_name(<?php echo $search['id']; ?>)"></span>
	                </div>
                </td>
                <td><?php echo $search['creation_date']; ?></td>

                <?php if($this->users->is_administrator() and !wpl_sef::is_permalink_default()): ?>
                    <td><input type="text" id="wpl_addon_save_searches_alias<?php echo $search['id']; ?>" placeholder="<?php echo __('Set an alias for link...', 'real-estate-listing-realtyna-wpl'); ?>" onchange="wpl_addon_save_searches_alias(<?php echo $search['id']; ?>);" value="<?php echo $search['alias']; ?>" /></td>

                    <td><a class="wpl-addon-save-search-show-link-btn" id="wpl_addon_save_searches_link<?php echo $search['id']; ?>" href="<?php echo $this->save_searches->URL($search['id']); ?>" target="_blank" title="<?php echo __('Open SEF link', 'real-estate-listing-realtyna-wpl'); ?>"></a></td>
                <?php endif; ?>
                <td>
                    <div class="wpl-addon-save-search-notify-mode">
                        <input type="radio" id="wpl_notify_once_a_day<?php echo $search['id']; ?>" name="wpl_notify_mode<?php echo $search['id']; ?>" <?php echo (($search['notify_mode'] == 'once_a_day') ? 'checked="checked"' :''); ?> onchange="wpl_addon_save_searches_notify_mode(<?php echo $search['id']; ?>, 'once_a_day');" />
                        <label for="wpl_notify_once_a_day<?php echo $search['id']; ?>"> <?php echo __('Once a day', 'real-estate-listing-realtyna-wpl'); ?> </label>
                    </div>
                    <div class="wpl-addon-save-search-notify-mode">
                        <input type="radio" id="wpl_notify_after_adding_property<?php echo $search['id']; ?>" name="wpl_notify_mode<?php echo $search['id']; ?>" <?php echo (($search['notify_mode'] == 'after_adding_property') ? 'checked="checked"' :''); ?> onchange="wpl_addon_save_searches_notify_mode(<?php echo $search['id']; ?>, 'after_adding_property');" />
                        <label for="wpl_notify_after_adding_property<?php echo $search['id']; ?>"> <?php echo __('After adding a property', 'real-estate-listing-realtyna-wpl'); ?></label>
                    </div>
                </td>
                <td>
	                <?php
	                $search_fields = !empty($search['criteria']) ? json_decode($search['criteria'], true) : array();
	                $readable_criteria = wpl_global::generate_readable_criteria($search_fields);
	                ?>
	                <a class="wpl-addon-save-search-detail-btn" id="wpl_save_search_see_criteria<?php echo $search['id']; ?>" title="<?php echo __('Criteria', 'real-estate-listing-realtyna-wpl'); ?>" data-realtyna-lightbox-opts="position:center|title:<?php echo __('Criteria', 'real-estate-listing-realtyna-wpl'); ?>|reloadPage:false|wrapperClass:wpl-frontend-lightbox-wp" data-realtyna-lightbox href="#wpl_save_search_see_criteria_box<?php echo $search['id']; ?>"></a>
	                <div class="wpl-saved-search-criteria-box" id="wpl_save_search_see_criteria_box<?php echo $search['id']; ?>" style="display:none">
		                <?php foreach($readable_criteria as $field_name=>$field_value)
		                {
			                if(!empty($field_value)) echo '<p>'.$field_name.' = '.$field_value.'</p>';
		                }
		                ?>
	                </div>
                </td>
                <td><span class="wpl-addon-save-search-remove-btn" id="wpl_addon_save_searches_delete<?php echo $search['id']; ?>" onclick="wpl_addon_save_searches_delete(<?php echo $search['id']; ?>, 0);" title="<?php echo __('Delete', 'real-estate-listing-realtyna-wpl'); ?>"></span></td>
            </tr>
            <?php endforeach; ?>

            <?php if(!count($this->searches)): ?>
                <tr>
                    <td class="wpl-gen-grid-no-result" colspan="1000">
                        <?php echo __('No saved search to show!', 'real-estate-listing-realtyna-wpl'); ?>
                    </td>
                </tr>
            <?php endif; ?>

        </tbody>
    </table>
</div>
<style>
	.wpl-saved-search-criteria-box {display: none;}
	.wpl-saved-search-criteria-box p {margin: 10px;}
</style>