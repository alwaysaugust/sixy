<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');

_wpl_import('views.frontend.addon_save_searches.wpl_abstract');

class wpl_addon_save_searches_controller extends wpl_addon_save_searches_controller_abstract
{
    public $wplraw = 1;
}